#!/bin/bash
TMP=/tmp/speed.$$
trap "/bin/rm $TMP" 0 1 2 3 15

expressions='
	(n[i][1]*n[i][2])
	(m[i][1]+m[i][2])
	(m[i][1]*m[i][2])
	log(m[i][1]*m[i][2])
	(m[i][1]*m[i][2])+(n[i][1]*n[i][2])
	log(m[i][1]*m[i][2])*log(n[i][1]*n[i][2])
	log(m[i][1]*m[i][2])*(n[i][1]*n[i][2])
	log(m[i][1]*m[i][2])+(n[i][1]*n[i][2])
	log(m[i][1]*m[i][2])*(n[i][1]+n[i][2])
	log(m[i][1]*m[i][2])+log(n[i][1]*n[i][2])'

for EXPR in $expressions; do
    echo "--- $EXPR ---"
    echo 'n	rho	p-value	sigma	exec'
    for sana in '' .sparse .cores .gdb; do
	echo `
	fgrep -l "sana$sana " *.progress | xargs hawk '
	    /^Running sana/{sana[ARGIND]=$2}
	    /^filePath:/{gsub(".*/",""); gsub(".gw$",""); name[ARGIND][++nf[ARGIND]]=$0}
	    /^adjMatrix size:/{n[ARGIND][nf[ARGIND]]=$NF}
	    /^totalEdgeWeight:/{m[ARGIND][nf[ARGIND]]=$NF}
	    /^Executed SANA_s3/{T[ARGIND]=1*$NF}
	    END{
		for(i=1;i<=ARGIND;i++){
		    deg1=m[i][1]/n[i][1]; deg2=m[i][2]/n[i][2];
		    print '"$EXPR"',T[i],sana[i],name[i][1],name[i][2]
		}
	    }' | pearson` "sana$sana" | sed 's/ /\t/g'
    done | tee $TMP
    awk '{print $2}' $TMP | stats | sed 's/var.*//'
done
